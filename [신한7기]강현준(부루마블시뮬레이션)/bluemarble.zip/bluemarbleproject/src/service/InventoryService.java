package service;

import java.util.ArrayList;
import java.util.List;

import dao.InventoryDAO;
import dto.InventoryItemDTO;
import dto.UsersDTO;
import model.ItemPage;

public class InventoryService {

	public static ItemPage<InventoryItemDTO> getInventory(UsersDTO loginUser, int curPage, int selectSize) {
		// 페이지를 구하는 로직 , 컨트롤러로 받은 현재 페이지에 따라 아이템들의 목록을 다르게 보여줌
		List<InventoryItemDTO> items = InventoryDAO.selectInventoryItemsByUserId(loginUser.getUserId());
		int totalCount = items.size();
		int totalPage = totalCount / selectSize;
		if (totalCount % selectSize != 0) {
		    totalPage++;
		}
		int start = ( curPage - 1 ) * selectSize;
		int end = Math.min((( curPage - 1 ) * selectSize + selectSize),totalCount);
		List<InventoryItemDTO> pageItems 
			= new ArrayList<InventoryItemDTO>(items.subList(start, end));
		ItemPage<InventoryItemDTO> page = ItemPage.<InventoryItemDTO>builder()
		.curPage(curPage)
		.totalPage(totalPage)
		.pageItems(pageItems)
		.build();
		return page;
	}

}
