package service;

import java.util.ArrayList;
import java.util.List;

import dao.CardDAO;
import dao.GameLogDAO;
import dao.InventoryDAO;
import dao.ItemDAO;
import dao.LandDAO;
import dao.UsersDAO;
import dto.CardDTO;
import dto.InventoryItemDTO;
import dto.ItemDTO;
import dto.LandDTO;
import dto.UsersDTO;
import model.Difficulty;
import model.GameResult;
import model.GameState;
import model.Land;
import model.LandType;
import model.Player;
import strategy.DoubleDiceStrategy;
import strategy.MinusDiceStrategy;
import strategy.NormalDiceStrategy;
import strategy.PlusDiceStrategy;
import view.GameView;

public class GameService {

	public static GameState startGame(UsersDTO loginUser, Difficulty diff) {
		Player player = Player.builder()
				.ai(false)
				.jailed(false)
				.money(diff.getStartMoney())
				.tollMultiplier(1.0)
				.name(loginUser.getUserName())
				.position(0)
				.build();
		
		Player computer = Player.builder()
				.ai(true)
				.jailed(false)
				.money(diff.getComputerMoney())
				.tollMultiplier(1.0)
				.name("컴퓨터")
				.position(0)
				.build();

		
		player.setStrategy(new NormalDiceStrategy());
		computer.setStrategy(new NormalDiceStrategy());
		
		
		List<LandDTO> landDtoList = LandDAO.selectAll();
		List<Land> lands = new ArrayList<Land>();
		 
		for(LandDTO land : landDtoList) {
			lands.add(Land.builder()
					.info(land)
					.owner(null)
					.curTollPrice(land.getTollPrice())
					.curBuyPrice(land.getBuyPrice())
					.curUpgrade(0)
					.landType(LandType.valueOf(land.getLandType()))
					.build());
		}

		List<CardDTO> cards = CardDAO.selectAll();
		GameState game = GameState.builder()
				.loginUser(loginUser)
				.playerTurn(true)
				.player(player)
				.computer(computer)
				.turn(0)
				.diceSum(0)
				.lands(lands)
				.cards(cards)
				.build();
		
		return game;
	}
	
	public static boolean playTurn(GameState game, Player player) {
		//턴 증가
		game.setTurn(game.getTurn() + 1);
		// 감옥에 있는지 확인 , 일정 횟수 이상이면 풀림
	    if (player.isJailed()) {
	        player.setTurnJailed(player.getTurnJailed() + 1);

	        if (player.getTurnJailed() >= 3) {
	            player.setJailed(false);
	            player.setTurnJailed(0);
	        }

	        return false;
	    }
	    
		// 주사위 던지기
		int moveCount = player.getStrategy().rollDice(game);
		// 주사위 일반주사위로 변환
		player.setStrategy(new NormalDiceStrategy());
		player.setUseItem(false);
		// 주사위 값만큼 이동
		int setPostion = (player.getPosition() + moveCount) % game.getLands().size();
		player.setPosition(setPostion);
		return true;
		// 해당 땅 조사
	}

	public static String[] processAiTurn(GameState game,Player computer) {
		game.setPlayerTurn(false);
		String [] msg = {"","",""};
	    Land curLand = getCurrentLand(game, computer);
		msg[0] = "컴퓨터가 "
				+ curLand.getInfo().getLandName()
				+ "에 도착하였습니다!";
        LandType landType = curLand.getLandType();	// 땅의 유형 조사
	    // 유형에 따른 행동패턴 함수
	    switch (landType) {
	        case ATTRACTION -> {
	        		processAiAttractionLand(game, computer, curLand,msg);
	        }
	        case NORMAL -> {
	        		processAiNormalLand(game, computer, curLand,msg);
	        }
	        case CARD -> handleCardEvent(game, computer);
	        case EXPO -> {
	            Land targetLand = getRandomOwnedLand(game, computer);
	            if (targetLand != null) {
	                handleExpoEvent(game, computer, targetLand);
	            }
	        }
	        case JAIL -> handleJailEvent(game, computer);
	        case LUCKY -> handleLuckyEvent(game, computer);
	        case START -> {
	            Land targetLand = getRandomOwnedLand(game, computer);
	            if (targetLand != null) {
	                handleStartEvent(game, computer, targetLand);
	            }
	        }
	        case TRAIN -> handleTrainEvent(game, computer); 
	    }
		return msg;
	}

	private static void processAiAttractionLand(GameState game, Player computer, Land curLand, String[] msg) {
        if (curLand.getOwner() == null && canPurchase(computer, curLand)) {
            purchaseEvent(game, computer, curLand);
			msg[1] = "컴퓨터가 "
					+ curLand.getInfo().getLandName() + "을/를 " + (int)curLand.getCurBuyPrice()
					+ "원에 매수했습니다!";
        } else if (curLand.getOwner() != null) {
            payTollEvent(game, computer, curLand);
			msg[1] = "컴퓨터가 통행료"
					+ curLand.getInfo().getTollPrice()
					+ "원을 지불하였습니다!";
        }
    }

	private static void processAiNormalLand(GameState game, Player computer, Land curLand, String[] msg) {
		if (curLand.getOwner() == null && canPurchase(computer, curLand)) {
			purchaseEvent(game, computer, curLand);
			msg[1] = "컴퓨터가 "
					+ curLand.getInfo().getLandName() + "을/를 " + curLand.getCurBuyPrice()
					+ "원에 매수했습니다!";
		} else if (curLand.getOwner() == game.getPlayer()) {
			payTollEvent(game, computer, curLand);
			msg[1] = "컴퓨터가 통행료"
					+ curLand.getInfo().getTollPrice()
					+ "원을 지불하였습니다!";
			if (!game.isGameOver() && canTakeOver(computer, curLand)) {
				takeOverEvent(game, computer, curLand);
				msg[2] = "컴퓨터가 "
						+ curLand.getInfo().getLandName() + "을/를 " + curLand.getCurBuyPrice() * 1.5
						+ "원에 매수했습니다!";
			}
		}
	}

	private static boolean canTakeOver(Player computer, Land curLand) {
		// 컴퓨터가 인수할지 판단하는 코드 , 현재 소유 금액 >= 인수 금액 * 2 여야 true 반환.
		return computer.getMoney() >= curLand.getCurBuyPrice() * 1.5 * 2;
	}

	private static boolean canPurchase(Player computer, Land curLand) {
		// 컴퓨터가 인수할지 판단하는 코드 , 현재 소유 금액 >= 매수 * 2 여야 true 반환.
		return computer.getMoney() >= curLand.getCurBuyPrice() * 2;
	}

	public static boolean useItemsEvent(GameState game, InventoryItemDTO inventDTO) {
		// 아이템을 사용하는 이벤트 , 아이템의 효과에 따라 해당 효과 value의 효과를 낸다.
		if (game.getPlayer().isUseItem()) {
			GameView.gameBoardDisplay(game, "아이템을 이미 이번 턴에 사용하셨습니다.", "", "");
			return false;
		}
		ItemDTO item = ItemDAO.selectById(inventDTO.getItemid());
		String type = item.getEffectType();
		int value = item.getEffectValue();
		UsersDTO loginUser = game.getLoginUser();
		Player player = game.getPlayer(); 
		switch (type) {
			case "PLUS" -> {
				player.setStrategy(new PlusDiceStrategy(value));
			}
			case "MINUS" -> {
				player.setStrategy(new MinusDiceStrategy(value));
			}
			case "DOUBLE" -> {
				player.setStrategy(new DoubleDiceStrategy());
			}
			case "MONEY_PLUS" -> {
				player.setMoney(player.getMoney()+value);
			}
			default -> {
				System.out.println("알 수 없는 아이템 효과입니다: " + type);
				return false;
			}
		}
		player.setUseItem(true);
		// 인벤토리 수량 감소
		if (inventDTO.getQuantity() == 1) {
			InventoryDAO.deleteById(loginUser.getUserId(),inventDTO.getItemid());
		} else {
			InventoryDAO.updateQuantity(loginUser.getUserId(), inventDTO.getItemid(), inventDTO.getQuantity() - 1);
		}
        return true;
	}

	public static Land getCurrentLand(GameState game, Player player) {
		return game.getLands().get(player.getPosition());
	}

	public static void handleStartEvent(GameState game, Player player, Land selectLand) {
		int targetTollPrice = selectLand.getCurTollPrice() * 2;
		int targetBuyPrice = selectLand.getCurBuyPrice() * 2;
		selectLand.setCurTollPrice(targetTollPrice);
		selectLand.setCurBuyPrice(targetBuyPrice);
	}

	public static void handleExpoEvent(GameState game, Player player, Land selectLand) {
		int targetTollPrice = selectLand.getCurTollPrice() * 2;
		int targetBuyPrice = selectLand.getCurBuyPrice() * 2;
		selectLand.setCurTollPrice(targetTollPrice);
		selectLand.setCurBuyPrice(targetBuyPrice);
	}

	public static void handleTrainEvent(GameState game, Player player) {
		// 랜덤한 장소로 이동하고 landevent 발생
		int randomPosition = (int)(Math.random() * game.getLands().size());
		player.setPosition(randomPosition);
	}

	public static int handleLuckyEvent(GameState game, Player player) {
		int randomMoney = (int)(Math.random() * 4001) + 1000;
		int money = player.getMoney() + randomMoney;
		player.setMoney(money);
		return randomMoney;
	}

	public static void handleJailEvent(GameState game, Player player) {
		// 감옥 타일을 밟게되면 발생하는 이벤트 , player의 jailed 가 true가 되며 turn이 3번 지날때 까지 false가 되지 않음.
		// 이미 감옥에 갇혀있으면 jailed 수치를 올리고 일정수치 이상이면 풀리게
		player.setJailed(true);
		player.setTurnJailed(1);
	}

	public static CardDTO handleCardEvent(GameState game, Player player) {
		int randIndex = (int)(Math.random() * game.getCards().size());
		CardDTO card =  game.getCards().get(randIndex);
		switch (card.getEffectType()) {
			case "TOLL" -> {player.setTollMultiplier(card.getEffectValue());}
			case "GOLD" -> {player.setMoney(player.getMoney() + card.getEffectValue());}
			case "MOVE" -> {
					player.setPosition(card.getEffectValue());
					
				}
		}
		return card;
	}

	public static void takeOverEvent(GameState game, Player player, Land curLand) {
		// 주인이 있는 땅을 매수하는 이벤트 , player의 money가 curLand의 buyprice * 1.5 보다 많아야 하며 해당 금액만큼 차감됨
		Player owner = curLand.getOwner();
		
		if (owner == null)
			throw new IllegalStateException("takeOverEvent는 땅 주인이 있어야 함");
		if (player.getMoney() < curLand.getCurBuyPrice()){
			System.out.println("인수금액보다 돈이 적습니다!");
			return;
		}
		
		int takeOverPrice = (int) (curLand.getCurBuyPrice() * 1.5);
	    player.setMoney(player.getMoney() - takeOverPrice);
	    owner.setMoney(owner.getMoney() + takeOverPrice);
	    curLand.setOwner(player);
	}

	public static void purchaseEvent(GameState game, Player player, Land curLand) {
		// 주인이 없는 땅을 인수하는 이벤트 , player의 money가 curLand의 buyprice 보다 많아야 하며 해당 금액만큼 차감됨
		if (curLand.getOwner() != null)
			throw new IllegalStateException("purchaseEvent는 땅 주인이 없어야 함");
		if (player.getMoney() < curLand.getCurBuyPrice()){
			System.out.println("매수금액보다 돈이 적습니다!");
			return;
		}
		
		int price = player.getMoney() - curLand.getCurBuyPrice();
		
		curLand.setOwner(player);
		player.setMoney(price);
	}

	public static void payTollEvent(GameState game, Player player, Land curLand) {
		// 주인이 있는 땅을 밟게 되면 통행료를 지불해야하는 이벤트 , player의 money가 curLand의 tollprice보다 적으면 게임종료
		Player owner = curLand.getOwner();
		
		if (owner == null)
			throw new IllegalStateException("payTollEvent는 땅 주인이 있어야 함");
	    if (owner == player) {
	        return;
	    }

	    int toll = (int)(curLand.getCurTollPrice() * player.getTollMultiplier());
	    player.setTollMultiplier(1.0);

	    if (player.getMoney() < toll) {
	        game.setGameOver(true);
	        game.setWinner(owner);
	        return;	
	    }
	    player.setMoney(player.getMoney() - toll);
	    owner.setMoney(owner.getMoney() + toll);
    }


	public static Land getRandomOwnedLand(GameState game, Player player) {
	    List<Land> ownedLands = new ArrayList<>();
	    for (Land land : game.getLands()) {
	        boolean isMyLand = land.getOwner() == player;
	        boolean isMovableLand =
	                land.getLandType() == LandType.NORMAL ||
	                land.getLandType() == LandType.ATTRACTION;

	        if (isMyLand && isMovableLand) {
	            ownedLands.add(land);
	        }
	    }
	    if (ownedLands.isEmpty()) {
	        return null;
	    }
	    int randomIndex = (int)(Math.random() * ownedLands.size());
	    return ownedLands.get(randomIndex);
	}


	public static void quitGameEvent(GameState game) {
		// 게임 중단 flag ON
		game.setExit(true);
	}


	public static void setGameResult(GameState game) {
		// 게임 중단 정산 , 골드 획득 및 경험치 획득 , 게임 기록 남기기
		GameResult result;
		if (game.isExit()) 
			result = GameResult.GIVE_UP;
		else if (game.getWinner() == game.getPlayer()) 
			result = GameResult.WIN;
		else
			result = GameResult.LOSE;
		
	    String logDescription = result.getDescription();
	    double expMultiplier = result.getExpMultiplier();
	    double goldMultiplier = result.getGoldMultiplier();
		
	    int baseExp = 100;
	    int baseGold = 1000;
	    
	    int addMoney = (int)(baseGold * goldMultiplier);
	    int addExp = (int)(baseExp * expMultiplier);
		// UserDAO로 정산
	    UsersDTO loginUser = game.getLoginUser();
		UsersDAO.addReword(loginUser.getUserId(), addMoney , addExp);
		// GameLogDAO로 정산
		GameLogDAO.insertLog(loginUser.getUserId(),logDescription,addMoney,addExp,game.getTurn()); 
		
		game.setResult(result);
		game.setResultGold((int)(baseGold * goldMultiplier));
		game.setResultExp((int)(baseExp * expMultiplier));
		
		int sumMoney = loginUser.getGold() + addMoney;
		int sumExp = loginUser.getExperience() + addExp;
		loginUser.setGold(sumMoney);
		loginUser.setExperience(sumExp);
	}


	public static boolean turnStartprocess(GameState game) {
		game.setDice1(0);
		game.setDice2(0);
		game.setDiceSum(0);
		game.setPlayerTurn(true);
		if (game.getWinner() == null )
			return false;
		return true;
	}
}
