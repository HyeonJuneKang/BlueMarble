package service;

import java.util.ArrayList;
import java.util.List;

import dao.GameLogDAO;
import dto.GameLogDTO;
import dto.UsersDTO;
import model.ItemPage;

public class GameLogService {

	public static ItemPage<GameLogDTO> getLog(UsersDTO loginUser, int curPage, int selectSize) {
		// 페이지를 구하는 로직 , 컨트롤러로 받은 현재 페이지에 따라 아이템들의 목록을 다르게 보여줌
		List<GameLogDTO> items = GameLogDAO.selectGameLogByUserId(loginUser.getUserId());
		int totalCount = items.size();
		int totalPage = totalCount / selectSize;
		if (totalCount % selectSize != 0) {
		    totalPage++;
		}
		int start = ( curPage - 1 ) * selectSize;
		int end = Math.min((( curPage - 1 ) * selectSize + selectSize),totalCount);
		List<GameLogDTO> pageItems 
			= new ArrayList<GameLogDTO>(items.subList(start, end));
		ItemPage<GameLogDTO> page = ItemPage.<GameLogDTO>builder()
		.curPage(curPage)
		.totalPage(totalPage)
		.pageItems(pageItems)
		.build();
		return page;
	}

}
