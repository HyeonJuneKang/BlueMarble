package service;

import java.util.ArrayList;
import java.util.List;

import dao.InventoryDAO;
import dao.ItemDAO;
import dao.UsersDAO;
import dto.InventoryDTO;
import dto.InventoryItemDTO;
import dto.ItemDTO;
import dto.UsersDTO;
import model.ItemPage;

public class ShopService {

	public static ItemPage<ItemDTO> getItemPage(int curPage, int selectSize) {
		// 페이지를 구하는 로직 , 컨트롤러로 받은 현재 페이지에 따라 아이템들의 목록을 다르게 보여줌
		List<ItemDTO> items = ItemDAO.selectAll();
		int totalCount = items.size();
		int totalPage = totalCount / selectSize;
		if (totalCount % selectSize != 0) {
		    totalPage++;
		}
		int start = ( curPage - 1 ) * selectSize;
		int end = Math.min((( curPage - 1 ) * selectSize + selectSize),totalCount);
		List<ItemDTO> pageItems 
			= new ArrayList<ItemDTO>(items.subList(start, end));
		ItemPage<ItemDTO> page = ItemPage.<ItemDTO>builder()
		.curPage(curPage)
		.totalPage(totalPage)
		.pageItems(pageItems)
		.build();
		
		return page;
	}

	public static void buyItem(UsersDTO loginUser, ItemDTO selectedItem) {
		// 아이템을 구매하는 로직 , 돈이 부족하면 구매를 못하게 막아야함
		//ItemDTO에 일치하는 아이템을 사는거임
		if ( loginUser.getGold() < selectedItem.getPrice()) {
			//아이템 구매 불가 View
			System.out.println("돈이 부족합니다. 아이템 구매 불가");
			return;
		}
		// 아이템 구매 1개씩 산다는 가정.
		// 플레이어의 돈을 Update , 인벤토리에 해당 아이템이 없으면 INSERT , 있으면 UPDATE
		InventoryDTO inventory = InventoryDAO.selectByItemid(loginUser.getUserId(),selectedItem.getItemId());
		int price = loginUser.getGold() - selectedItem.getPrice();
		if (inventory == null) {
			InventoryDAO.insertItem(loginUser.getUserId(),selectedItem.getItemId());
			UsersDAO.updateGold(loginUser.getUserId(),price);
		} else {
			InventoryDAO.updateQuantity(loginUser.getUserId(),selectedItem.getItemId(),inventory.getQuantity() + 1);
			UsersDAO.updateGold(loginUser.getUserId(),price);
		}
		
		loginUser.setGold(price);
	}

	public static void sellItem(UsersDTO loginUser, InventoryItemDTO selectedItem) {
		//아이템을 판매하는 로직 , 기존에 인벤토리에 존재하는 아이템을 판매하므로 없는 아이템을 판매는 불가
		//단, 아이템을 판매할 때 수량이 0 이면 데이터를 제거 , 수량이 1이상이면 -1씩 하여 quantity를 변경
		//보유 골드는 아이템의 가격을 증가시켜 업데이트를 한다.
		int price = loginUser.getGold() + selectedItem.getPrice();
		if (selectedItem.getQuantity() == 1) {
			InventoryDAO.deleteById(loginUser.getUserId(),selectedItem.getItemid());
		} else {
			InventoryDAO.updateQuantity(loginUser.getUserId(), selectedItem.getItemid(), selectedItem.getQuantity() - 1);
		}
		UsersDAO.updateGold(loginUser.getUserId(), price);
		loginUser.setGold(price);
	}

}
