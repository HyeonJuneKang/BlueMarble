package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.LandDTO;
import utill.DBUtil;

public class LandDAO {
	
	static Connection conn = null; //DB연결
	static Statement st = null; //SQL문보내는 통로, 바인딩변수 사용불가능 
	static PreparedStatement pst = null;
	static ResultSet rs = null; //Select문 결과가 들어온다. 
	
	public static List<LandDTO> selectAll() {
		List<LandDTO> landList = new ArrayList<LandDTO>();
		String sql_selectAll = """
				SELECT * FROM land
				""";
		conn = DBUtil.dbConnect();
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql_selectAll);
			while(rs.next()) {
				LandDTO land = LandDTO.builder()
						.LandID(rs.getInt("LAND_ID"))
						.landType(rs.getString("LAND_TYPE"))
						.landName(rs.getString("LAND_NAME"))
						.buyPrice(rs.getInt("BUY_PRICE"))
						.tollPrice(rs.getInt("TOLL_PRICE"))
						.upgradeCost(rs.getInt("UPGRADE_COST"))
						.upgradeMax(rs.getInt("UPGRADE_MAX"))
						.build();
				landList.add(land);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return landList;
	}
	
}
