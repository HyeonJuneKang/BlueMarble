package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.ItemDTO;
import utill.DBUtil;

public class ItemDAO {
	static Connection conn = null; //DB연결
	static Statement st = null; //SQL문보내는 통로, 바인딩변수 사용불가능 
	static PreparedStatement pst = null;
	static ResultSet rs = null; //Select문 결과가 들어온다. 
	
	public static List<ItemDTO> selectAll() {
		ItemDTO item = null;
		List<ItemDTO> items = new ArrayList<>();
		String sql_selectAll = """
				SELECT * FROM item
				""";
		conn = DBUtil.dbConnect();
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql_selectAll);
			while(rs.next()) {
				item = ItemDTO.builder()
						.itemId(rs.getInt("ITEM_ID"))
						.itemName(rs.getString("ITEM_NAME"))
						.price(rs.getInt("PRICE"))
						.description(rs.getString("DESCRIPTION"))
						.effectType(rs.getString("EFFECT_TYPE"))
						.effectValue(rs.getInt("EFFECT_VALUE"))
						.build();
				items.add(item);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return items;
	}

	public static ItemDTO selectById(Integer itemid) {
		ItemDTO item = null;
		String sql_selectAll = """
				SELECT * FROM item WHERE item_id = ?
				""";
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_selectAll);
			pst.setInt(1, itemid);
			rs = pst.executeQuery();
			while(rs.next()) {
				item = ItemDTO.builder()
						.itemId(rs.getInt("ITEM_ID"))
						.itemName(rs.getString("ITEM_NAME"))
						.price(rs.getInt("PRICE"))
						.description(rs.getString("DESCRIPTION"))
						.effectType(rs.getString("EFFECT_TYPE"))
						.effectValue(rs.getInt("EFFECT_VALUE"))
						.build();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, pst, rs);
		}
		return item;
	}

}
