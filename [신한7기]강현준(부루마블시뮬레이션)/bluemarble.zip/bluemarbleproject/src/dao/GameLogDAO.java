package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.GameLogDTO;
import utill.DBUtil;

public class GameLogDAO {
	static Connection conn = null; //DB연결
	static Statement st = null; //SQL문보내는 통로, 바인딩변수 사용불가능 
	static PreparedStatement pst = null;
	static ResultSet rs = null; //Select문 결과가 들어온다. 
	public static boolean insertLog(String userId, String logDescription,int goldGain,int expGain, int turn) {
		int resultCnt = 0;;
		String sql_select = """
				INSERT INTO game_log(
				game_id,
				user_id,
				description,
				gold_gain,
				exp_gain,
				turn_count,
				play_date
				) values ( GAME_LOG_SEQ.NEXTVAL , ? , ? , ?, ? , ? , SYSDATE )
				""";
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_select);
		    pst.setString(1, userId);
		    pst.setString(2, logDescription);
		    pst.setInt(3, goldGain);
		    pst.setInt(4, expGain);
		    pst.setInt(5, turn);
		    resultCnt = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, pst, null);
		}
		if (resultCnt == 0)
			return false;
		return true;
	}
	public static List<GameLogDTO> selectGameLogByUserId(String userId) {
		String sql_select = """
				SELECT * FROM game_log WHERE user_id = ? ORDER BY PLAY_DATE DESC
				""";
		List<GameLogDTO> loglist = new ArrayList<GameLogDTO>();
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_select);
			pst.setString(1, userId);
			rs = pst.executeQuery();
			int index = 1;
			while(rs.next()) {
				GameLogDTO log = GameLogDTO.builder()
						.gameId(index++)
						.result(rs.getString("description"))
						.expGain(rs.getInt("exp_gain"))
						.goldGain(rs.getInt("gold_gain"))
						.turnCount(rs.getInt("turn_count"))
						.playDate(rs.getDate("play_date"))
						.build();
				loglist.add(log);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return loglist;
	}
	
}
