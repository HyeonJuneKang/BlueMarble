package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.InventoryDTO;
import dto.InventoryItemDTO;
import utill.DBUtil;



public class InventoryDAO {

	static Connection conn = null; //DB연결
	static Statement st = null; //SQL문보내는 통로, 바인딩변수 사용불가능 
	static PreparedStatement pst = null;
	static ResultSet rs = null; //Select문 결과가 들어온다. 
	public static List<InventoryItemDTO> selectInventoryItemsByUserId(String userid) {
		List<InventoryItemDTO> itemList = new ArrayList<InventoryItemDTO>();
		InventoryItemDTO item = null;
		String sql_select = """
		        SELECT 
		            i.item_id,
		            i.item_name,
		            i.description,
		            i.price,
		            inv.quantity
		        FROM inventory inv
		        JOIN item i ON inv.item_id = i.item_id
		        WHERE inv.user_id = ?
		        """;
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_select);
			pst.setString(1, userid);
			rs = pst.executeQuery();
			while(rs.next()) {
				item = InventoryItemDTO.builder()
						.itemid(rs.getInt("ITEM_ID"))
						.itemName(rs.getString("ITEM_NAME"))
						.description(rs.getString("DESCRIPTION"))
						.quantity(rs.getInt("QUANTITY"))
						.price(rs.getInt("PRICE"))
						.build();
				itemList.add(item);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.dbDisconnect(conn, pst, rs);
		}
		
		return itemList;
	}

	public static InventoryDTO selectByItemid(String userid, Integer itemid) {
		InventoryDTO inventory = null;
		String sql_select = """
				SELECT * FROM inventory WHERE item_id = ? AND user_id = ?
				""";
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_select);
			pst.setInt(1, itemid);
			pst.setString(2, userid);
			rs = pst.executeQuery();
			while(rs.next()) {
				inventory = InventoryDTO.builder()
						.userId(rs.getString("USER_ID"))
						.itemId(rs.getInt("ITEM_ID"))
						.quantity(rs.getInt("QUANTITY"))
						.build();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.dbDisconnect(conn, pst, rs);
		}
		return inventory;
	}

	public static void insertItem(String userId, Integer itemId) {
		String sql_select = """
				INSERT INTO inventory ( item_id , user_id , quantity ) 
						VALUES ( ?,?,1 )
				""";
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_select);
			pst.setInt(1, itemId);
			pst.setString(2, userId);
			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.dbDisconnect(conn, pst, null);
		}
		return;
	}

	public static boolean updateQuantity(String userId, Integer itemId,int amount) {
		int result = 0;
		String sql_update = """
				UPDATE inventory SET quantity = ? 
				WHERE user_id = ?
				AND item_id = ?
				""";
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_update);
			pst.setInt(1, amount);
			pst.setString(2, userId);
			pst.setInt(3, itemId);
			result = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.dbDisconnect(conn, pst, null);
		}
		if (result == 0)
			return false;
		return true;
	}

	public static boolean deleteById(String userId, Integer itemId) {
		int result = 0;
		String sql_update = """
				DELETE FROM inventory WHERE user_id = ? AND item_id = ?
				""";
		conn = DBUtil.dbConnect();
		try {
			pst = conn.prepareStatement(sql_update);
			pst.setString(1, userId);
			pst.setInt(2, itemId);
			result = pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBUtil.dbDisconnect(conn, pst, null);
		}
		if (result == 0)
			return false;
		return true;
		
	}

	
}
