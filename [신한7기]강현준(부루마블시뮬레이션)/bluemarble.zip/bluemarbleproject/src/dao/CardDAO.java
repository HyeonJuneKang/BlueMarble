package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dto.CardDTO;
import utill.DBUtil;

public class CardDAO {
	
	static Connection conn = null; //DB연결
	static Statement st = null; //SQL문보내는 통로, 바인딩변수 사용불가능 
	static PreparedStatement pst = null;
	static ResultSet rs = null; //Select문 결과가 들어온다. 
	
	public static List<CardDTO> selectAll() {
		List<CardDTO> cardList = new ArrayList<CardDTO>();
		String sql_selectAll = """
				SELECT * FROM card
				""";
		conn = DBUtil.dbConnect();
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql_selectAll);
			while(rs.next()) {
				CardDTO land = CardDTO.builder()
						.cardId(rs.getInt("CARD_ID"))
						.cardName(rs.getString("CARD_NAME"))
						.description(rs.getString("DESCRIPTION"))
						.effectType(rs.getString("EFFECT_TYPE"))
						.effectValue(rs.getInt("EFFECT_VALUE"))
						.build();
				cardList.add(land);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return cardList;
	}

}
