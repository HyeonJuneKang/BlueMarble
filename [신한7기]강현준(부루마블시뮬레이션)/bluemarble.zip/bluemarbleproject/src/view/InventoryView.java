package view;

import dto.InventoryItemDTO;
import dto.UsersDTO;
import model.ItemPage;

public class InventoryView {
	public static void clearScreen() {
		for(int i = 0; i < 35;i++) {
			System.out.println();
		}
	}
	public static void inventoryDisplay(UsersDTO user, ItemPage<InventoryItemDTO> page) {
		clearScreen();
	    System.out.print("""
			+=======================================================================================+
			|                                  >>> 부 루 마 블 <<<                                    |
			+=======================================================================================+
			|                                                                                       |
			|                         ┌──────────────────────────────┐                              |
			|                         │         Inventory            │                              |
			|                         └──────────────────────────────┘                              |
			|                                                                                       |
			|   번호 | 아이템명       | 설명                           | 가격        | 개수                 |
			|---------------------------------------------------------------------------------------|
			""");
		
	    int index = 1;

	    for (InventoryItemDTO item : page.getPageItems()) {
	        System.out.printf(
	            "|   %-3d| %-12s| %-28s | %,9dG| %5dx                %n",
	            index++,
	            item.getItemName(),
	            item.getDescription(),
	            item.getPrice(),
	            item.getQuantity()
	        );

	        System.out.println("|");
	    }

	    System.out.printf("""
			|                                                                                       
			|
			|                             < %-2s  / %-2s >                                                                                         
			|                              7. 이전 페이지                                              
			|                              8. 다음 페이지                                              
			|                              9. 게임 메뉴                                               
			|                                                        PLAYER : %-20s 
			|                                                        GOLD  : %,7d G                 
			|                                                                                       
			+=======================================================================================+
			""",
			page.getCurPage(),
			page.getTotalPage(),
	        user.getUserName(),
	        user.getGold()
	    );

	    System.out.print("입력 >> ");
	}
}
