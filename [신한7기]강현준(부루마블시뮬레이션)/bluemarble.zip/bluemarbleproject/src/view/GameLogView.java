package view;

import dto.GameLogDTO;
import dto.UsersDTO;
import model.ItemPage;

public class GameLogView {
	public static void clearScreen() {
		for(int i = 0; i < 35;i++) {
			System.out.println();
		}
	}
	public static void logHistory(UsersDTO user, ItemPage<GameLogDTO> page) {
		clearScreen();
		System.out.print("""
				+=======================================================================================+
				|                                  >>> 부 루 마 블 <<<                                    |
				+=======================================================================================+
				|                                                                                       |
				|                         ┌──────────────────────────────┐                              |
				|                         │        Match history         │                              |
				|                         └──────────────────────────────┘                              |
				|                                                                                       |
				|         번호    | 결과       |    골드   |     경험치     | 턴   |  일자                     |
				|---------------------------------------------------------------------------------------|
				""");
	    for (GameLogDTO item : page.getPageItems()) {
	        System.out.printf(
	                "|           %-4d | %-6s  | %-8d  | %-8d    | %-4d | %tF               |%n",
	                item.getGameId(),
	                item.getResult(),
	                item.getGoldGain(),
	                item.getExpGain(),
	                item.getTurnCount(),
	                item.getPlayDate()
	        );
	    }
		System.out.printf("""
				|                                        
				|                             < %-2s  / %-2s >                                                    
				|                              7. 이전 페이지                                              
				|                              8. 다음 페이지                                                       
				|                              9. 게임 메뉴                                               
				|                                                        PLAYER : %-20s 
				|                                                        GOLD  : %,15d G
				|                                                                                       |
				+=======================================================================================+
				""",
				page.getCurPage(),
				page.getTotalPage(),
				user.getUserName(),
				user.getGold()
				);
	    
		System.out.print("입력 >>");
	}
}
