package view;
import dto.InventoryItemDTO;
import dto.ItemDTO;
import dto.UsersDTO;
import model.ItemPage;



public class ShopView {
	public static void clearScreen() {
		for(int i = 0; i < 35;i++) {
			System.out.println();
		}
	}
	
	public static void shopLobbyDisplay(UsersDTO user) {
		clearScreen();
		String screen = String.format("""
				+=======================================================================================+
				|                                  >>> 부 루 마 블 <<<                                    |
				+=======================================================================================+
				|                                                                                       
				|                         ┌──────────────────────────────┐                              
				|                         │         Shop Lobby           │                              
				|                         └──────────────────────────────┘                              
				|                                                                                       
				|                              1. 아이템 구매                                              
				|                              2. 아이템 판매                                              
				|                              9. 게임 메뉴                                               
				|                                                                                       
				|                                                                                       
				|                                                        PLAYER : %-20s 
				|                                                        GOLD  : %,15d G
				|                                                                                       
				+=======================================================================================+
				""",
				user.getUserName(),
				user.getGold()
				);

		System.out.println(screen);
		System.out.print("입력 >>");
	}
	public static void itemPurchaseDisplay(UsersDTO user, ItemPage<ItemDTO> page) {
		clearScreen();
		String screen = """
				+=======================================================================================+
				|                                  >>> 부 루 마 블 <<<                                    |
				+=======================================================================================+
				|                                                                                       |
				|                         ┌──────────────────────────────┐                              |
				|                         │        Item Purchase         │                              |
				|                         └──────────────────────────────┘                              |
				|                                                                                       |
				|                   선택 | 아이템명    | 설명                            |  가격                             
				""";
		
		
		
		String screen3 = String.format("""
			|                                                                                       
			|                             < %-2s  / %-2s >                                              
			|                                                                                       
			|                              7. 이전 페이지                                              
			|                              8. 다음 페이지                                              
			|                              9. 상점 메뉴                                               
			|                                                        PLAYER : %-20s  
			|                                                        GOLD  : %,7d G              
			|                                                                                       |
			+=======================================================================================+
				""",
				page.getCurPage(),
				page.getTotalPage(),
				user.getUserName(),
				user.getGold()
				);
		System.out.print(screen);
		/*
		 * page에 있는 아이템을 출력한다.
		 * page의 item의 size만큼 item을 번호를 매겨서 출력을 한다.
		 */
		int index = 1;
		System.out.println("|");
		for(ItemDTO item :page.getPageItems()) {
			System.out.print(String.format("""
|                    %d |  %-8s|   %-30s|   %dG|                  
|                                                                                      					
				""",index++,item.getItemName(),item.getDescription(),item.getPrice()));
		}
		
	    
		System.out.println(screen3);
		System.out.print("입력 >>");
	}
	public static void itemSellDisplay(UsersDTO user, ItemPage<InventoryItemDTO> page) {
		clearScreen();
	    System.out.print("""
			+=======================================================================================+
			|                                  >>> 부 루 마 블 <<<                                    |
			+=======================================================================================+
			|                                                                                       |
			|                         ┌──────────────────────────────┐                              |
			|                         │          Item Sell           │                              |
			|                         └──────────────────────────────┘                              |
			|                                                                                       |
			| 선택 | 아이템명       | 설명                         | 가격        | 개수                     |
			|---------------------------------------------------------------------------------------|
			""");
	    int index = 1;
	    for (InventoryItemDTO item : page.getPageItems()) {
	        System.out.printf(
	            "|  %-4d | %-12s | %-30s | %,9dG | %5dx                %n",
	            index++,
	            item.getItemName(),
	            item.getDescription(),
	            item.getPrice(),
	            item.getQuantity()
	        );

	        System.out.println("|                                                                                       ");
	    }
	    System.out.printf("""
			|                                                                                       
			|                          
			|                             < %-2s  / %-2s >                                                                 
			|                              7. 이전 페이지                                              
			|                              8. 다음 페이지                                              
			|                              9. 상점 메뉴                                               
			|                                                        PLAYER : %-20s 
			|                                                        GOLD  : %,7d G              
			|                                                                                       |
			+=======================================================================================+
			""",
			page.getCurPage(),
			page.getTotalPage(),
	        user.getUserName(),
	        user.getGold()
	    );
		// for문으로 플레이어 아이템 db로 보여주기
		System.out.print("입력 >>");
	}

}
