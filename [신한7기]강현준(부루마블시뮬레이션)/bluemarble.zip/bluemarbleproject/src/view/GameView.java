package view;

import java.util.List;

import dto.InventoryItemDTO;
import dto.UsersDTO;
import model.GameState;
import model.ItemPage;
import model.Land;

public class GameView {
	public static void clearScreen() {
		for(int i = 0; i < 40;i++) {
			System.out.println();
		}
	}
	public static void gameMenuDisplay(UsersDTO user) {
		clearScreen();
		String screen = String.format("""
				+=======================================================================================+
				|                                  >>> 부 루 마 블 <<<                                    |
				+=======================================================================================+
				|                                                                                       
				|                         ┌──────────────────────────────┐                              
				|                         │         Game Option          │                              
				|                         └──────────────────────────────┘                              
				|                                                                                       
				|                              1. 쉬움                                                   
				|                              2. 보통                                                   
				|                              3. 어려움                                                  
				|                              9. 뒤로가기                                                
				|                                                                                       
				|                         ┌──────────────────────────────┐                              
				|                         │     난이도를 선택 해 주세요.                                    
				|                         │                                                            
				|                         └──────────────────────────────┘                                  
				|                                                                                       
				+=======================================================================================+
				""",
				user.getUserName(),
				user.getGold());
	
		System.out.println(screen);
		System.out.print("입력 >>");
	}
	public static void gameBoardDisplay(GameState game,String msg1,String msg2,String msg3) {	 
		clearScreen();
	    String messageBox = makeMessageBox(msg1,msg2,msg3);
	    String middleBox = makeMiddleBox(game,messageBox);
	    String screen = makeGameBoardBase(game);
	    System.out.println(screen);
	    System.out.print(middleBox);
	}
	
	public static void menuDisplay(String... menus) {
	    System.out.println("+------------------------------------------------------+");

	    for (String menu : menus) {
	        System.out.printf("| %-52s \n", menu);
	    }

	    System.out.println("+------------------------------------------------------+");
	    System.out.print("입력 >> ");
	}

	public static void gameMenuDisplay(GameState game) {
	    gameBoardDisplay(game,"","","");
	    menuDisplay(
	        "1. 주사위 굴리기",
	        "2. 아이템 사용",
	        "3. 인벤토리",
	        "9. 그만하기"
	    );
	}
	
	
	public static void itemUseDisplay(GameState game,UsersDTO loginUser, ItemPage<InventoryItemDTO> page) {
	    clearScreen();

	    String screen = makeGameBoardBase(game);
	    System.out.println(screen);

	    System.out.print("""
			+=======================================================================================+
			|   번호 | 아이템명       | 설명                           | 개수                             |
			|---------------------------------------------------------------------------------------|
			""");
	    int index = 1;

	    for (InventoryItemDTO item : page.getPageItems()) {
	        System.out.printf(
	            "|   %-3d| %-12s| %-28s |%-5dx                %n",
	            index++,
	            item.getItemName(),
	            item.getDescription(),
	            item.getQuantity()
	        );
	    }
	    System.out.printf("""
			|                             < %-2s  / %-2s >                                                                                         
			|                              7. 이전 페이지          |                                      
			|                              8. 다음 페이지          |     사용하실 아이템을 선택 해 주세요.                                   
			|                              9. 뒤로 가기           |                                              
			+=======================================================================================+
			""",
			page.getCurPage(),
			page.getTotalPage()
	    );
	    System.out.print("입력 >>");
	}
	public static void inventoryDisplay(GameState game, ItemPage<InventoryItemDTO> page) {
	    clearScreen();

	    String screen = makeGameBoardBase(game);
	    System.out.println(screen);

	    System.out.print("""
			+=======================================================================================+
			|   번호 | 아이템명       | 설명                           | 개수                             |
			|---------------------------------------------------------------------------------------|
			""");
	    int index = 1;

	    for (InventoryItemDTO item : page.getPageItems()) {
	        System.out.printf(
	            "|   %-3d| %-12s| %-28s |%-5dx                %n",
	            index++,
	            item.getItemName(),
	            item.getDescription(),
	            item.getQuantity()
	        );
	    }
	    System.out.printf("""
			|                             < %-2s  / %-2s >                                                                                         
			|                              7. 이전 페이지                                              
			|                              8. 다음 페이지                                              
			|                              9. 뒤로 가기                                                         
			+=======================================================================================+
			""",
			page.getCurPage(),
			page.getTotalPage()
	    );
	    System.out.print("입력 >>");
	}
	
	public static void TakeOverDisplay(GameState game) {
		Land curLand = game.getLands().get(game.getPlayer().getPosition());
		String msg1 = "이미 주인이 있는 땅입니다.";
		String msg2 = curLand.getInfo().getLandName() + "을(를) 매수하시겠습니까?";
		String msg3 = "가격 : " + curLand.getCurBuyPrice() * 1.5 + "원";		
		gameBoardDisplay(game,msg1,msg2,msg3);
	    menuDisplay(
	        "1. 인수 하기",
	        "2. 지나가기"
	    );
	}
	public static void purchaseDisplay(GameState game) {
		Land curLand = game.getLands().get(game.getPlayer().getPosition());
		String msg1 = "빈 땅입니다.";
		String msg2 = curLand.getInfo().getLandName() + "을(를) 매수하시겠습니까?";
		String msg3 = "가격 : " + curLand.getCurBuyPrice() + "원";
	    gameBoardDisplay(game,msg1,msg2,msg3);
	    menuDisplay(
	        "1. 매수 하기",
	        "2. 지나가기"
	    );
	}
	public static void resultDisplay(GameState game, String sb) {
		clearScreen();
	    String screen = String.format("""
				+=======================================================================================+
				|                                  >>> 부 루 마 블 <<<                                    |
				+=======================================================================================+
				|                                                                                       
				|                         ┌──────────────────────────────┐                              
				|                         │         Result                                         
				|                         └──────────────────────────────┘                              
				|                                                                                       
				|                              Player     : %s
				|                                                                                       
				|                              Experience : +%d
				|                              Gold       : +%d                                                         
				|                                                                                       
				|                         ┌──────────────────────────────┐                              
				|                         │            %s                                    
				|                         │   잠시후 게임로비로 돌아갑니다%s                                                          
				|                         └──────────────────────────────┘                                  
				|                                                                                       
				+=======================================================================================+
	            """,
	            game.getPlayer().getName(),
	            game.getResultExp(),
	            game.getResultGold(),
	            game.getResult(),
	            sb
	    		);
	    System.out.println(screen);

	}
	private static String makeGameBoardBase(GameState game) {
	    String playerName = game.getPlayer().getName();
	    String aiName = game.getComputer().getName();

	    int playerMoney = game.getPlayer().getMoney();
	    int aiMoney = game.getComputer().getMoney();

	    String playerPos = game.getLands()
	            .get(game.getPlayer().getPosition())
	            .getInfo()
	            .getLandName();

	    String aiPos = game.getLands()
	            .get(game.getComputer().getPosition())
	            .getInfo()
	            .getLandName();

	    return String.format("""
	            +==============================================================================================================+
	            |                                      >>> 부 루 마 블 <<<                                                       |
	            +==============================================================================================================+
	                                                                                                                          
	              [%s] -> [%s] -> [%s] -> [%s] -> [%s] -> [%s] -> [%s] ->   [%s] 
	                ^                                                                                                         |       
	                |                                                                                                         v       
	              [%s]                                                                                              [%s] 
	                ^                                                                                                         |       
	                |                                                                                                         v       
	              [%s]                                                                                              [%s] 
	                ^                                                                                                         |       
	                |                                                                                                         v       
	              [%s]                                                                                              [%s] 
	                ^                                                                                                         |       
	                |                                                                                                         v       
	              [%s]                                                                                              [%s] 
	                ^                                                                                                         |       
	                |                                                                                                         v       
	              [%s]                                                                                              [%s] 
	                ^                                                                                                         |       
	                |                                                                                                         v       
	              [%s]                                                                                              [%s] 
	                ^                                                                                                         |        
	                |                                                                                                         v       
	              [%s] <- [%s] <- [%s] <- [%s] <- [%s] <- [%s] <- [%s] <- [%s] 
	                                                                                                                          
	            +==============================================================================================================+

	            +==============================================================================================================+
	            | PLAYER1 : %-25s      PLAYER2 : %-25s          현재 턴 : %d 턴   
	            | 보유자산 : %d 원                         보유자산 : %d 원                                                    
	            | 현재위치 : %-25s        현재위치 : %-25s                                      
	            +==============================================================================================================+
	            """,

	            land(game, 0), land(game, 1), land(game, 2), land(game, 3),
	            land(game, 4), land(game, 5), land(game, 6), land(game, 7),

	            land(game, 27), land(game, 8),
	            land(game, 26), land(game, 9),
	            land(game, 25), land(game, 10),
	            land(game, 24), land(game, 11),
	            land(game, 23), land(game, 12),
	            land(game, 22), land(game, 13),

	            land(game, 21), land(game, 20), land(game, 19), land(game, 18),
	            land(game, 17), land(game, 16), land(game, 15), land(game, 14),

	            playerName,
	            aiName,
	            game.getTurn(),
	            playerMoney,
	            aiMoney,
	            playerPos,
	            aiPos
	    );
	}
	private static String makeMessageBox(String msg1, String msg2, String msg3) {
	    return String.format("""
	            +--------------------------------------------------+
	            | MESSAGE                                          
	            | %-48s 
	            | %-48s 
	            | %-48s 
	            |                                                  
	            |                                                  
	            |                                                  
	            +--------------------------------------------------+
	            """,
	            msg1,
	            msg2,
	            msg3
	    );
	}
	private static String land(GameState game, int idx) {
	    List<Land> lands = game.getLands();
	    Land curLand = lands.get(idx);
	
	    String name = curLand.getInfo().getLandName();
	
	    // 1. 소유자 표시
	    if (curLand.getOwner() != null) {
	        if (curLand.getOwner() == game.getPlayer()) {
	            name = "★" + name;   // 플레이어 소유
	        } else if (curLand.getOwner() == game.getComputer()) {
	            name = "◆" + name;   // AI 소유
	        }
	    }
	
	    // 2. 현재 위치 표시
	    boolean player = game.getPlayer().getPosition() == idx;
	    boolean ai = game.getComputer().getPosition() == idx;
	
	    if (player && ai) {
	        name += "(PA)";
	    } else if (player) {
	        name += "(P)";
	    } else if (ai) {
	        name += "(A)";
	    }
	
	    return String.format("%-8s", name);
	}
	private static String makeMiddleBox(GameState game, String messageBox) {
	    String[] diceLines = dicePair(game.getDice1(), game.getDice2()).split("\n");
	    String dice = String.format("""
	            +--------------------------------------------------+
	            | Turn : %-41s |
	            | DICE : %-41s |
	            |        %-41s |
	            |        %-41s |
	            |        %-41s |
	            |        %-41s |
	            | SUM  : %-41d |
	            +--------------------------------------------------+
	            """,
	            game.isPlayerTurn() ? "Player":"Computer",
	            diceLines[0],
	            diceLines[1],
	            diceLines[2],
	            diceLines[3],
	            diceLines[4],
	            game.getDiceSum()
	    );
		return sideBySide(dice, messageBox, 4);
	}
	private static String dicePair(int d1, int d2) {
	    String[] left = diceFace(d1).split("\n");
	    String[] right = diceFace(d2).split("\n");
	
	    StringBuilder sb = new StringBuilder();
	
	    for (int i = 0; i < left.length; i++) {
	        sb.append(left[i])
	          .append("  ")
	          .append(right[i])
	          .append("\n");
	    }
	
	    return sb.toString();
	}
	private static String diceFace(int n) {
	    return switch (n) {
	        case 1 -> """
	                ┌───┐
	                │   │
	                │ ● │
	                │   │
	                └───┘""";
	        case 2 -> """
	                ┌───┐
	                │●  │
	                │   │
	                │  ●│
	                └───┘""";
	        case 3 -> """
	                ┌───┐
	                │●  │
	                │ ● │
	                │  ●│
	                └───┘""";
	        case 4 -> """
	                ┌───┐
	                │● ●│
	                │   │
	                │● ●│
	                └───┘""";
	        case 5 -> """
	                ┌───┐
	                │● ●│
	                │ ● │
	                │● ●│
	                └───┘""";
	        case 6 -> """
	                ┌───┐
	                │● ●│
	                │● ●│
	                │● ●│
	                └───┘""";
	        default -> """
	                ┌───┐
	                │ ? │
	                │ ? │
	                │ ? │
	                └───┘""";
	    };
	}
	private static String sideBySide(String leftBox, String rightBox, int gap) {
	    String[] leftLines = leftBox.stripTrailing().split("\n");
	    String[] rightLines = rightBox.stripTrailing().split("\n");
	
	    int leftWidth = 0;
	    for (String line : leftLines) {
	        leftWidth = Math.max(leftWidth, line.length());
	    }
	
	    int height = Math.max(leftLines.length, rightLines.length);
	    StringBuilder sb = new StringBuilder();
	
	    String gapSpace = " ".repeat(gap);
	
	    for (int i = 0; i < height; i++) {
	        String left = i < leftLines.length ? leftLines[i] : "";
	        String right = i < rightLines.length ? rightLines[i] : "";
	
	        sb.append(padRight(left, leftWidth))
	          .append(gapSpace)
	          .append(right)
	          .append("\n");
	    }
	
	    return sb.toString();
	}
	private static String padRight(String str, int width) {
	    return str + " ".repeat(Math.max(0, width - str.length()));
	}
}



