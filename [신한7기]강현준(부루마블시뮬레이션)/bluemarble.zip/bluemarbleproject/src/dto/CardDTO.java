package dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor@AllArgsConstructor
@Getter@Setter@Builder
public class CardDTO {
    private Integer cardId;
    private String cardName;
    private String description;
    private String effectType;
    private Integer effectValue;
}