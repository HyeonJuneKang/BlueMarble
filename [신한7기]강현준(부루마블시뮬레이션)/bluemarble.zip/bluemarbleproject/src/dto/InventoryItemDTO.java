package dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter@Setter@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InventoryItemDTO {
	private Integer itemid;
    private String itemName;
    private Integer quantity;
    private Integer price;
    private String description;
}