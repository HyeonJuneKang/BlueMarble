package controller;
import java.util.Scanner;

import dto.CardDTO;
import dto.GameLogDTO;
import dto.InventoryItemDTO;
import dto.ItemDTO;
import dto.UsersDTO;
import model.Difficulty;
import model.GameState;
import model.ItemPage;
import model.Land;
import model.LandType;
import model.Player;
import service.GameLogService;
import service.GameService;
import service.InventoryService;
import service.LoginService;
import service.ShopService;
import view.GameView;
import view.InventoryView;
import view.LobbyView;
import view.LoginView;
import view.GameLogView;
import view.ShopView;


public class MainController {
    static Scanner sc = new Scanner(System.in);
    static UsersDTO loginUser;
    
    public static void main(String[] args) {
        while (true) {
            loginLoop();

            if (loginUser == null) {
                break; // 로그인 메뉴에서 종료 선택
            }

            gameLoop();
        }
        LoginView.exitDisplay();
        sleep(2000);
    }

    private static void loginLoop() {
        boolean isStop = false;

        while (!isStop) {
            LoginView.loginMenuDisplay();
            String job = sc.nextLine();

            switch (job) {
	            case "1" -> {
	                loginUser = login();
	
	                if (loginUser != null) {
	                    isStop = true;
	                }
	            }
                case "2" -> signUser(); // 회원가입
                case "3" ->resetPassword(); // 비밀번호 초기화
                case "9" -> { // 프로그램 종료
                		loginUser = null;
                    isStop = true;
                }
				default ->System.out.println("작업선택 오류. 다시선택");
            }
        }
    }

	private static UsersDTO login() {
       	String inputID = "";
    	String inputPassword = "";
    	// ID 입력
    	LoginView.loginDisplay(inputID,inputPassword,"아이디를 입력 해 주세요.","");
    	inputID = sc.nextLine();
    	// Password 입력
    	LoginView.loginDisplay(inputID,inputPassword,"패스워드를 입력 해 주세요.","");
    	inputPassword = sc.nextLine();
    	
    	// 로그인 성공했다고 가정
    	StringBuilder sb = new StringBuilder();
    	sb.append("로그인 중");
    	for (int i = 0 ; i < 3;i++) {
    		sb.append(".");
    		LoginView.loginDisplay(inputID,inputPassword,sb.toString(),"");
    		sleep(1000);
    	}
    	
    	
    	UsersDTO user = LoginService.login(inputID, inputPassword);
    	//로그인 성공
    	if (user  != null) { 
    		sb.delete(0, sb.length());
        	sb.append("잠시후 게임 메뉴로 입장합니다");
        	for (int i = 0 ; i < 3;i++) {
        		sb.append(".");
        		LoginView.loginDisplay(inputID,inputPassword,"로그인에 성공 하셨습니다!",sb.toString());
        		sleep(1000);
        	}
        	return user ;
    	}
    	//로그인 실패
    	else {
    		sb.delete(0, sb.length());
        	sb.append("잠시후 로그인 페이지로 돌아갑니다");
        	for (int i = 0 ; i < 3;i++) {
        		sb.append(".");
        		LoginView.loginDisplay(inputID,inputPassword,"로그인에 실패 하셨습니다!",sb.toString());
        		sleep(1000);
        	}
        	return null;
    	}
		
	}

	private static void signUser() {
    	String inputID = "";
    	String inputPass = "";
    	String inputUsername = "";
    	String inputQue = "";
    	String inputAns = "";
    	LoginView.signDisplay("아이디를 입력 해 주세요.","",inputID,inputPass,inputUsername,inputQue,inputAns);
    	inputID = sc.nextLine();
    	UsersDTO user = LoginService.checkID(inputID);
    	
    	if (user != null) {
    		LoginView.signDisplay("해당 아이디는 존재하는 아이디 입니다.","잠시후 로그인 페이지로 돌아갑니다.",
    										inputID,inputPass,inputUsername,inputQue,inputAns);
    		sleep(1500);
    		return;
    	}
    	
    	LoginView.signDisplay("패스워드를 입력 해 주세요.","",inputID,inputPass,inputUsername,inputQue,inputAns);
    	inputPass = sc.nextLine();
    	LoginView.signDisplay("닉네임을 입력 해 주세요.","",inputID,inputPass,inputUsername,inputQue,inputAns);
    	inputUsername = sc.nextLine();
    	LoginView.signDisplay("비밀번호 초기화 질문을 입력 해 주세요.","",inputID,inputPass,inputUsername,inputQue,inputAns);
    	inputQue = sc.nextLine();
    	LoginView.signDisplay("질문에 대한 답을 입력 해 주세요.","",inputID,inputPass,inputUsername,inputQue,inputAns);
    	inputAns = sc.nextLine();
    	//Service로 해당정보 INSERT
    	
    	UsersDTO newUser = UsersDTO.builder()
    	        .userId(inputID)
    	        .password(inputPass)
    	        .userName(inputUsername)
    	        .question(inputQue)
    	        .answer(inputAns)
    	        .gold(0)
    	        .experience(0)
    	        .build();
    	
    	
    	if (LoginService.sign(newUser)){
        	StringBuilder sb = new StringBuilder();
        	sb.append("잠시후 로그인 페이지로 돌아갑니다");
        	for (int i = 0 ; i < 3; i++) {
        		sb.append(".");
        		LoginView.signDisplay("회원가입에 성공하셨습니다.",sb.toString(),inputID,inputPass,inputUsername,inputQue,inputAns);
        		sleep(1000);
        	}
    	} else {
        	StringBuilder sb = new StringBuilder();
        	sb.append("잠시후 로그인 페이지로 돌아갑니다");
        	for (int i = 0 ; i < 3; i++) {
        		sb.append(".");
        	    LoginView.signDisplay(
        	            "회원가입에 실패했습니다.",
        	            "잠시후 로그인 페이지로 돌아갑니다.",
        	            inputID, inputPass, inputUsername, inputQue, inputAns
        	        );
        	    sleep(1000);
        	}
    	}
		
	}

	private static void resetPassword() {
		String inputID = "";
		String inputPass = "";
		String inputAns = "";
		LoginView.resetPassIdInput("아이디를 입력 해 주세요.","",inputID ,"","****");
		inputID = sc.nextLine();
		//Service로 해당 아이디가 DB에 있는지 확인
		
		UsersDTO user = LoginService.checkID(inputID);
		
		if (user == null) {
			LoginView.resetPassIdInput("해당 아이디가 없습니다.","",inputID ,"","****");
			sleep(1500);
			return;
		}
	
		// 질문에 대한 답 확인
		LoginView.resetPassIdInput("질문에 대한 답을 입력해 주세요.",user.getQuestion(),user.getUserId() ,user.getUserName(),"****");
		inputAns = sc.nextLine().trim();
		
		// 답 정합성 체크
		StringBuilder sb = new StringBuilder();
		sb.append("질문에 대한 정답을 확인중 입니다");
		for (int i = 0 ; i < 3;i++) {
			sb.append(".");
			LoginView.resetPassIdInput(inputAns,sb.toString(),inputID ,user.getUserName(),inputPass);
			sleep(1000);
		}
		
		if (!inputAns.equals(user.getAnswer())) {
			LoginView.resetPassIdInput("질문에 대한 답이 틀렸습니다!",user.getQuestion(),user.getUserId() ,user.getUserName(),"****");
			sleep(1500);
			return;
		}
		// 비밀번호 입력하기
		LoginView.resetPassIdInput("새로운 비밀번호를 입력 해 주세요","",inputID ,user.getUserName(),inputPass);
		inputPass = sc.nextLine();
		//Service로 비밀번호 UPDATE
		if (!LoginService.updatePass(user,inputPass)) {
			System.out.println("비밀번호 초기화 실패");
			return;
		}
		
		sb.delete(0, sb.length());
		sb.append("잠시후 로그인 페이지로 돌아갑니다");
		for (int i = 0 ; i < 3;i++) {
			sb.append(".");
			LoginView.resetPassIdInput("비밀번호 초기화에 성공하셨습니다.",sb.toString(),inputID ,user.getUserName(),inputPass);
			sleep(1000);
		}
		
	}

	private static void gameLoop() {
        boolean isStop = false;

        while (!isStop) {
            LobbyView.clearScreen();
            LobbyView.lobbyDisplay(loginUser);
            String job = sc.nextLine();

            switch (job) {
                case "1" -> difficultyMenuLoop(); // 게임 시작
                case "2" -> shopLoop(); // 상 점
                case "3" -> inventoryLoop(); // 인벤토리
                case "4" -> gameLogLoop(); // 게임 기록
                case "9" -> { //로그 아웃
                		StringBuilder sb = new StringBuilder();
	            		for (int i = 0 ; i < 3;i++) {
	            			sb.append(".");
	            			LobbyView.logoutDisplay(sb.toString());
	            			sleep(1000);
	            		}
                    loginUser = null;
                    isStop = true;
                }
                default -> System.out.println("작업선택 오류. 다시선택");
            }
        }
    }
    // 난이도 선택 : 초기 자금, 컴퓨터 자금이 달라짐
	private static void difficultyMenuLoop() {
		boolean isStop = false;
		while(!isStop) {
			GameView.gameMenuDisplay(loginUser);
			String job = sc.nextLine();
			switch (job) {
			    case "1" -> {
				    	playGameLoop(Difficulty.EASY);  //쉬움 
				    return;
			    }
			    case "2" -> {
				    	playGameLoop(Difficulty.NORMAL);//보통
				    	return;
			    }
			    case "3" -> {
				    	playGameLoop(Difficulty.HARD);	//어려움 
				    	return;
			    }
			    case "9" -> {isStop = true;}
			}
		}
	}

	private static void playGameLoop(Difficulty diff) {
		boolean isStop = false;
		// gamestate 생성
	    GameState game = GameService.startGame(loginUser, diff);
		// Service로 player ai 맵 로드  
		while(!isStop) {
			if (GameService.turnStartprocess(game)) {
				break;
			}
			GameView.gameMenuDisplay(game);
			String job = sc.nextLine();
	        switch (job) {
		        case "1" -> { //주사위 던지기
		        		sleep(1000);
			        	Player player = game.getPlayer();
		            if (GameService.playTurn(game, player)) // 사람 턴 -> 주사위 던지기 -> 땅 이동
		            		handleLandEvent(game, player);      // 도착한 땅 -> 선택지 or 결과 처리
		            else {
		            		GameView.gameBoardDisplay(game,player.getName() +"은/는 감옥에 있습니다.","","");
		            }
		            sleep(2000);
		            
		    	   		Player computer = game.getComputer();
					if(GameService.playTurn(game,computer)) {  // ai 턴 -> 주사위 던지기 -> 땅 이동
						String[] msg = GameService.processAiTurn(game,computer); // ai가 도착한 땅 -> 결과 보여주기
					    GameView.gameBoardDisplay(game,msg[0],msg[1],msg[2]);
					} else {
						GameView.gameBoardDisplay(game,computer.getName() +"은/는 감옥에 있습니다.","" ,"");
					}
				    sleep(2000);
		        }
	            case "2" -> useItemLoop(game); //아이템 사용
	            case "3" -> gameInventoryLoop(game); //인벤토리 보기
	            case "9" -> {						 //게임중단
		            	GameService.quitGameEvent(game);
		            	isStop = true;
	            }
	            default -> System.out.println("작업선택 오류. 다시선택");
	        }
		}
		GameService.setGameResult(game);
		StringBuilder sb = new StringBuilder();
		sb.delete(0, sb.length());
	    	sb.append("");
	    	for (int i = 0 ; i < 3;i++) {
	    		sb.append(".");
	    		GameView.resultDisplay(game,sb.toString());
	    		sleep(1000);
	    	}
	}

	private static void handleLandEvent(GameState game, Player player) {
        Land curLand = GameService.getCurrentLand(game, player); // 현재 땅 조사
        LandType landType = curLand.getLandType();	// 땅의 유형 조사
        switch (landType) {
	        case ATTRACTION -> handleAttractionLand(game, player, curLand);
	        case NORMAL -> handleNormalLand(game, player, curLand);
	        case CARD -> handleCardLand(game, player);
	        case EXPO -> handleExpoLand(game, player, curLand);
	        case JAIL -> handleJailLand(game, player);
	        case LUCKY -> handleLuckyLand(game, player);
	        case START -> handleStartLand(game, player, curLand);
	        case TRAIN -> handleTrainLand(game, player, curLand);
        }
	}
	private static void handleTrainLand(GameState game, Player player, Land curLand) {
		GameService.handleTrainEvent(game,player);
		GameView.gameBoardDisplay(game,"Train 이동!!","랜덤한 지역으로 이동합니다!","");
		sleep(1500);
		handleLandEvent(game, player); 
	}

	private static void handleStartLand(GameState game, Player player, Land curLand) {
		Land selectLand = GameService.getRandomOwnedLand(game,player);
		GameService.handleStartEvent(game,player,curLand);
		if (selectLand == null) {
			GameView.gameBoardDisplay(game,"START 이동!!","소유한 땅이 없습니다...","");
			return;
		}
		GameService.handleExpoEvent(game,player,selectLand);
	    GameView.gameBoardDisplay(game,"START 이동!!",selectLand.getInfo().getLandName() + "의 가격이 2배 증가했습니다!!",""
	    );
	}

	private static void handleLuckyLand(GameState game, Player player) {
		int result = GameService.handleLuckyEvent(game,player);
		GameView.gameBoardDisplay(game,"복불복 이동!",result+"의 돈을 휙득 했습니다!!","");
	}

	private static void handleJailLand(GameState game, Player player) {
		GameService.handleJailEvent(game,player);
		GameView.gameBoardDisplay(game,"감옥 이동!","3턴동안 쉽니다...","");
	}

	private static void handleExpoLand(GameState game, Player player, Land curLand) {
		Land selectLand = GameService.getRandomOwnedLand(game,player);
		//select 무작위로
		if (selectLand == null) {
			GameView.gameBoardDisplay(game,"엑스포 이동!","소유한 땅이 없습니다...","");
			return;
		}
		GameService.handleExpoEvent(game,player,selectLand);
	    GameView.gameBoardDisplay(game,"엑스포 이동!",selectLand.getInfo().getLandName() + "의 가격이 2배 증가했습니다!!",""
	    );
	}

	private static void handleCardLand(GameState game, Player player) {
		CardDTO card = GameService.handleCardEvent(game,player);
		GameView.gameBoardDisplay(game,"카드 뽑기!","카드 : " + card.getCardName(),card.getDescription());
		if ("MOVE".equals(card.getEffectType())) {
			sleep(1500);
			handleLandEvent(game, player); 
		}
	}

	private static void handleNormalLand(GameState game, Player player, Land curLand) {
        if(curLand.getOwner() == null) {
        		handlePurchase(game,player,curLand); // 구매 선택지
        } else if (curLand.getOwner() != player ){
        		GameService.payTollEvent(game, player, curLand); //통행료 지불
        		GameView.gameBoardDisplay(game, "상대방의 땅입니다.","통행료 "
        				+ curLand.getCurTollPrice()
        				+ " 원이 지불되었습니다.", "");
        		sleep(2000);
        		handleTakeOver(game,player,curLand); // 인수 선택지
        } else {
    			GameView.gameBoardDisplay(game, "당신의 땅입니다","","");
        }
	}

	private static void handleAttractionLand(GameState game, Player player, Land curLand) {
        if(curLand.getOwner() == null) {
        		handlePurchase(game,player,curLand);  // 구매 선택지
        } else if(curLand.getOwner() != player ) {
        		GameService.payTollEvent(game, player, curLand); //통행료 지불
        		GameView.gameBoardDisplay(game, "상대방의 땅입니다.","통행료 "
        				+ curLand.getCurTollPrice()
        				+ " 원이 지불되었습니다.", "");
        } else {
        		GameView.gameBoardDisplay(game, "당신의 땅입니다.","","");
        }
	}

	private static void handleTakeOver(GameState game, Player player, Land curLand) {
		while(true) {
			GameView.TakeOverDisplay(game);
			String job = sc.nextLine();
			switch(job) {
				case "1"->{ // 인수
					GameService.takeOverEvent(game,player,curLand);
	                return;
				}
				case "2"-> {return;} // 취소
				default -> System.out.println("작업선택 오류. 다시선택");
			}
		}
	}

	private static void handlePurchase(GameState game, Player player, Land curLand) {
		while(true) {
			GameView.purchaseDisplay(game);
			String job = sc.nextLine();
			switch(job) {
				case "1"->{ // 매수
					GameService.purchaseEvent(game,player,curLand);
	                return;
				}
				case "2"->{ // 취소
	                return;
				}
				default ->{
	                System.out.println("작업선택 오류. 다시선택");
				}
			}
		}
	}

	private static void gameInventoryLoop(GameState game) {
		boolean isStop = false;
		int curPage = 1;
		int selectSize = 5;
		while(!isStop) {
			ItemPage<InventoryItemDTO> page = InventoryService.getInventory(loginUser,curPage,selectSize);
			GameView.inventoryDisplay(game,page);
			String job = sc.nextLine();
			switch (job) {
				case "7"->{ // 이전페이지
					if (curPage > 1)
						curPage--;
				}
				case "8"->{ // 다음페이지
					if (curPage < page.getTotalPage())
						curPage++;
				}
				case "9" -> { //뒤로가기
					isStop = true;
				}
				default ->{
	                System.out.println("작업선택 오류. 다시선택");
				}
			}
		}
	}

	private static void useItemLoop(GameState game) {
		//플레이어 아이템 보여줌
		//game.player.setStrategy(선택한 dice)
		boolean isStop = false;
		int curPage = 1;
		int selectSize = 5;
		while(!isStop){
		ItemPage<InventoryItemDTO> page = InventoryService.getInventory(loginUser,curPage,selectSize);
		GameView.itemUseDisplay(game,loginUser,page);
			String job = sc.nextLine();
			switch(job) {
				case "1","2","3","4","5" -> { //아이템 선택 
					int jobNum = Integer.parseInt(job);
					
					if (jobNum > page.getPageItems().size()) {
						System.out.println("없는 아이템 번호입니다.");
						continue;
					}
					InventoryItemDTO item = page.getPageItems().get(jobNum - 1);
					GameService.useItemsEvent(game,item);
					GameView.gameBoardDisplay(game, "아이템 " + item.getItemName() + " 을/를 사용하셨습니다!", 
							"남은 아이템 개수: " + (item.getQuantity() - 1), "");
					sleep(1500);
					isStop = true;
				}
				case "7"->{ // 이전페이지
					if (curPage > 1)
						curPage--;
				}
				case "8"->{ // 다음페이지
					if (curPage < page.getTotalPage())
						curPage++;
				}
				case "9" -> { //뒤로가기
					isStop = true;
				}
				default ->System.out.println("작업선택 오류. 다시선택");
			}
		}
	}

	private static void gameLogLoop() {
		boolean isStop = false;
		int curPage = 1;
		int selectSize = 5;
		while(!isStop) {
			ItemPage<GameLogDTO> page = GameLogService.getLog(loginUser,curPage,selectSize);
			GameLogView.logHistory(loginUser,page);
			String job = sc.nextLine();
			switch (job) {
				case "7"->{ // 이전페이지
					if (curPage > 1)
						curPage--;
				}
				case "8"->{ // 다음페이지
					if (curPage < page.getTotalPage())
						curPage++;
				}
				case "9" -> { //뒤로가기
					isStop = true;
				}
				default ->System.out.println("작업선택 오류. 다시선택");
			}
		}
	}

	private static void inventoryLoop() {
		boolean isStop = false;
		int curPage = 1;
		int selectSize = 5;
		while(!isStop) {
			ItemPage<InventoryItemDTO> page = InventoryService.getInventory(loginUser,curPage,selectSize);
			InventoryView.inventoryDisplay(loginUser,page);
			String job = sc.nextLine();
			switch (job) {
				case "7"->{ // 이전페이지
					if (curPage > 1)
						curPage--;
				}
				case "8"->{ // 다음페이지
					if (curPage < page.getTotalPage())
						curPage++;
				}
				case "9" -> {
					isStop = true;
				}
				default ->System.out.println("작업선택 오류. 다시선택");
			}
		}
	}

	private static void shopLoop() {
		boolean isStop = false;
		while(!isStop) {
			ShopView.shopLobbyDisplay(loginUser);
			String job = sc.nextLine();
			switch (job) {
				case "1" -> { // 아이템 구매
					shopPurchaseLoop();
				}
				case "2" -> { // 아이템 판매
					shopSellLoop();
				}
				case "9" -> { // 게임 로비
					isStop = true;
				}
				default ->System.out.println("작업선택 오류. 다시선택");
			}
		}
	}
	private static void shopPurchaseLoop() {
		boolean isStop = false;
		int curPage = 1;
		int selectSize = 5;
		while(!isStop) {
			ItemPage<ItemDTO> page = ShopService.getItemPage(curPage,selectSize);
			ShopView.itemPurchaseDisplay(loginUser,page);
			String job = sc.nextLine();
	        switch (job) {
				case "1","2","3","4","5" -> { //아이템 선택 
	                int jobNum = Integer.parseInt(job);

	                if (jobNum > page.getPageItems().size()) {
	                    System.out.println("없는 아이템 번호입니다.");
	                    break;
	                }

	                ItemDTO selectedItem = page.getPageItems().get(jobNum - 1);
	                ShopService.buyItem(loginUser, selectedItem);	
				}
				case "7" -> { // 이전 페이지
					if (curPage > 1)
						curPage--;
				}
				case "8" -> { // 다음 페이지
					if (curPage < page.getTotalPage())
						curPage++;
				}
				case "9" -> { //뒤로가기
					isStop = true;
				}
				default ->System.out.println("작업선택 오류. 다시선택");
	        }
		}
	}

	private static void shopSellLoop() {
		boolean isStop = false;
		int curPage = 1;
		int selectSize = 5;
		while(!isStop) {
			ItemPage<InventoryItemDTO> page = InventoryService.getInventory(loginUser,curPage,selectSize);
			ShopView.itemSellDisplay(loginUser,page);
			String job = sc.nextLine();
			switch (job) {
				case "1","2","3","4","5"->{
	                int jobNum = Integer.parseInt(job);

	                if (jobNum > page.getPageItems().size()) {
	                    System.out.println("없는 아이템 번호입니다.");
	                    break;
	                }

	                InventoryItemDTO selectedItem = page.getPageItems().get(jobNum - 1);
	                ShopService.sellItem(loginUser, selectedItem);	
				}
				case "7"->{ // 이전페이지
					if (curPage > 1)
						curPage--;
				}
				case "8"->{ // 다음페이지
					if (curPage < page.getTotalPage())
						curPage++;
				}
				case "9" -> { //뒤로가기
					isStop = true;
				}
				default ->System.out.println("작업선택 오류. 다시선택");
			}
		}
	}

	private static void sleep(int times) {
		try {
			Thread.sleep(times);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}