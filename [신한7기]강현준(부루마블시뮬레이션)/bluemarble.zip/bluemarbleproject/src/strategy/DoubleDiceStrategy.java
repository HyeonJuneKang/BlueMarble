package strategy;

import model.GameState;

public class DoubleDiceStrategy implements DiceStrategy {

    @Override
    public int rollDice(GameState game) {
        int dice = (int)(Math.random() * 6) + 1;

        int dice1 = dice;
        int dice2 = dice;

        int result = dice1 + dice2;

        // GameState에 주사위 값 저장 필드가 있으면 사용
        game.setDice1(dice1);
        game.setDice2(dice2);
        game.setDiceSum(result);
        return result;
    }
}