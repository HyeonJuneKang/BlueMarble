package strategy;

import lombok.AllArgsConstructor;
import model.GameState;

@AllArgsConstructor
public class PlusDiceStrategy implements DiceStrategy {
	
	int value;
	@Override
	public int rollDice(GameState game) {
		
		int dice1  = (int)(Math.random() * 6) + 1;
		int dice2  = (int)(Math.random() * 6) + 1;
		
		int result = dice1 + dice2 + value;
		game.setDice1(dice1);
		game.setDice2(dice2);
		game.setDiceSum(result);
		return result;
		
	}

}
