package strategy;

import model.GameState;

public interface DiceStrategy {
	public int rollDice(GameState game);
}
