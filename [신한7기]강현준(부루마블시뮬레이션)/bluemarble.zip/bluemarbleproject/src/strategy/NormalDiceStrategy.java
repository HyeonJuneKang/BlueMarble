package strategy;

import model.GameState;

public class NormalDiceStrategy implements DiceStrategy {

	@Override
	public int rollDice(GameState game) {
		
		int dice1  = (int)(Math.random() * 6) + 1;
		int dice2  = (int)(Math.random() * 6) + 1;
		
		game.setDice1(dice1);
		game.setDice2(dice2);
		game.setDiceSum(dice1+dice2);
		return dice1 + dice2;
		
	}


}
