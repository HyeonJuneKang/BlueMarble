package model;

public enum LandType {
	START,
    NORMAL,
    ATTRACTION,
    JAIL,
    EXPO,
    CARD,
    TRAIN,
    LUCKY
}