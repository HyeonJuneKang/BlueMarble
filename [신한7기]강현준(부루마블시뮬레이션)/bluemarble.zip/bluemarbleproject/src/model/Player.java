package model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import strategy.DiceStrategy;

@Getter@Setter@Builder

public class Player {
	private DiceStrategy strategy;
    private String name;
    private int money;
    private double tollMultiplier; 
    private int position;

    	private boolean useItem;
    private boolean ai;
    private boolean jailed;
    private int turnJailed;
    
}
