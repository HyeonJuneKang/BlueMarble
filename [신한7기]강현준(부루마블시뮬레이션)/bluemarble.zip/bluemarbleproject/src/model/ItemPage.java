package model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

/*  기존 코드 인벤토리DB 와 아이템DB 모두 현재 페이지 / 전체 페이지 기능을 구현하기 위해 class 필드를 
 *  추가하고 다르게 사용하려 하였는데 GPT가 <> 제네릭 써보라해서 써봄
 * 	private List<InventoryItemDTO> pageInvents;
    private List<ItemDTO> pageItems;
 */
@AllArgsConstructor
@Getter@Builder
public class ItemPage <T>{
	private List<T> pageItems;
    private int curPage;
    private int totalPage;
}