package model;

import java.util.List;

import dto.CardDTO;
import dto.UsersDTO;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter@Setter@Builder
public class GameState {
	private GameResult result;
	private int resultExp;
	private int resultGold;
	private UsersDTO loginUser;
	private Player player;
	private Player computer;
	private boolean playerTurn;
    private boolean gameOver;
    private boolean exit;
    private Player winner;
	private List<Land> lands;
	private List<CardDTO> cards;
	private int turn;
    private int dice1;
    private int dice2;
    private int diceSum;
}
