package model;

public enum Difficulty {
    EASY(20000,20000),
    NORMAL(15000,20000),
    HARD(10000,20000);
	
	int startMoney;
	int computerMoney;
	Difficulty(int startMoney,int computerMoney){
		this.startMoney = startMoney;
		this.computerMoney = computerMoney;
	}
	public int getStartMoney() {
		return startMoney;
	}
	public int getComputerMoney() {
		return computerMoney;
	}
}