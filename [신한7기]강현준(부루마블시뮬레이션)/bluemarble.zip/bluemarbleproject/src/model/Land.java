package model;


import dto.LandDTO;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter@Setter@Builder
public class Land {
	private LandDTO info;
	private LandType landType;
	private Player owner;
	private int curUpgrade;
	private int curTollPrice;
	private int curBuyPrice;
	
}
