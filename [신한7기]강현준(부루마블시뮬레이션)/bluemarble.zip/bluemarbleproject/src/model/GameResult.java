package model;

public enum GameResult {
    WIN("승리", 1.0, 1.0),
    LOSE("패배", 0.5, 0.5),
    GIVE_UP("포기", 0.1, 0.1);

    private final String description;
    private final double expMultiplier;
    private final double goldMultiplier;

    GameResult(String description, double expMultiplier, double goldMultiplier) {
        this.description = description;
        this.expMultiplier = expMultiplier;
        this.goldMultiplier = goldMultiplier;
    }

    public String getDescription() {
        return description;
    }

    public double getExpMultiplier() {
        return expMultiplier;
    }

    public double getGoldMultiplier() {
        return goldMultiplier;
    }
}